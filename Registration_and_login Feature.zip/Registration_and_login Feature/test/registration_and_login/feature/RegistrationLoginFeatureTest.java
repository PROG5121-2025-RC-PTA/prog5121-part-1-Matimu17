/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package registration_and_login.feature;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
import org.junit.jupiter.api.Test;

public class RegistrationLoginFeatureTest {

    Registration_and_loginfeature.Login login = new Registration_and_loginfeature.Login();

    // === Test: Username is correctly formatted
    public void testCorrectUsernameFormat() {
        login.registerUser("kyl_1", "Pass1@word", "+27838968976", "Kyle", "Smith");
        String message = login.returnLoginStatus("kyl_1", "Pass1@word");
        assertEquals("Welcome Kyle Smith, it is great to see you again.", message);
    }

    // === Test: Username is incorrectly formatted ===
    
    public void testIncorrectUsernameFormat() {
        String message = login.registerUser("Kyl!!!!!", "Ch&i&sec@ke99!", "+27838968976", "Jane", "Doe");
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", message);
    }

    // === Test: Password meets complexity ===
    @Test
    public void testPasswordMeetsComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&i&sec@ke99!"));
    }

    // === Test: Password does not meet complexity ===
    @Test
    public void testPasswordFailsComplexity() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    // === Test: Cell phone number is correctly formatted ===
    @Test
    public void testCellNumberCorrectFormat() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    // === Test: Cell phone number is incorrectly formatted ===
    @Test
    public void testCellNumberIncorrectFormat() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    // === Test: Login successful ===
    @Test
    public void testLoginSuccess() {
        login.registerUser("kyl_1", "Pass1@word", "+27838968976", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Pass1@word"));
    }

    // === Test: Login failed ===
   @Test
    public void testLoginFail() {
        login.registerUser("kyl_1", "Pass1@word", "+27838968976", "Kyle", "Smith");
        assertFalse(login.loginUser("wrongUser", "wrongPass"));
    }

    // === Test: checkUserName() returns true for valid username == @Test
    @Test
    public void testCheckUserName_Valid() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    // === Test: checkUserName() returns false for invalid username ===
    @Test
    public void testCheckUserName_Invalid() {
        assertFalse(login.checkUserName("Kyl!!!!!"));
    }

    public void assertFalse(boolean checkUserName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(String welcome_Kyle_Smith_it_is_great_to_see_you, String message) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertTrue(boolean checkPasswordComplexity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

  
