/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package registration_and_login.feature;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import registration_and_login.feature.Registration_and_loginfeature.Login; // Adjust package if needed

public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    @Test
    public void testUsernameCorrectlyFormatted() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        assertFalse(login.checkUserName("Kyl!!!!!"));
    }

    @Test
    public void testPasswordMeetsComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&i&sec@ke99!"));
    }

    @Test
    public void testPasswordFailsComplexity() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testPhoneNumberCorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testPhoneNumberIncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testSuccessfulRegistrationAndLogin() {
        String response = login.registerUser("kyl_1", "Ch&i&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertTrue(response.contains("successfully"));

        boolean loginSuccess = login.loginUser("kyl_1", "Ch&i&sec@ke99!");
        assertTrue(loginSuccess);

        String loginMessage = login.returnLoginStatus("kyl_1", "Ch&i&sec@ke99!");
        assertEquals("Welcome Kyle Smith, it is great to see you again.", loginMessage);
    }

    @Test
    public void testFailedLogin() {
        login.registerUser("kyl_1", "Ch&i&sec@ke99!", "+27838968976", "Kyle", "Smith");
        boolean loginSuccess = login.loginUser("wrong", "wrongpass");
        assertFalse(loginSuccess);
    }

    @Test
    public void testRegistrationInvalidUsername() {
        String response = login.registerUser("invalid", "Ch&i&sec@ke99!", "+27838968976", "Kyle", "Smith");
        assertTrue(response.contains("Username is not correctly formatted"));
    }

    @Test
    public void testRegistrationInvalidPassword() {
        String response = login.registerUser("kyl_1", "password", "+27838968976", "Kyle", "Smith");
        assertTrue(response.contains("Password is not correctly formatted"));
    }

    @Test
    public void testRegistrationInvalidPhone() {
        String response = login.registerUser("kyl_1", "Ch&i&sec@ke99!", "08966553", "Kyle", "Smith");
        assertTrue(response.contains("Cell phone number incorrectly formatted"));
    }
}



