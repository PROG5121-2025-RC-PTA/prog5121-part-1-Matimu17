/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.junit.jupiter;

/**
 *
 * @author RC_Student_lab
 */
public class api {

    public static class AfterEach {

        public AfterEach() {
        }
    }

    public static class AfterAll {

        public AfterAll() {
        }
    }

    public static class BeforeEach {

        public BeforeEach() {
        }
    }

    public static class BeforeAll {

        public BeforeAll() {
        }
    }

    public static class Test {

        public Test() {
        }
    }

    public static class Assertions {

        public Assertions() {
        }
    }
    
}
