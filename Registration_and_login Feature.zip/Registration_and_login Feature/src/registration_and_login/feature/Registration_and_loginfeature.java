/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registration_and_login.feature;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.JOptionPane;

public class Registration_and_loginfeature {


    // User class
    static class User {
        public String username;
        public String password;
        public String cellNumber;
        public String firstName;
        public String lastName;

        public User(String username, String password, String cellNumber, String firstName, String lastName) {
            this.username = username;
            this.password = password;
            this.cellNumber = cellNumber;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
    }

    // Login feature
    static class Login {
        private User registeredUser;

        public boolean checkUserName(String username) {
            return username.contains("_") && username.length() <= 5;
        }

        public boolean checkPasswordComplexity(String password) {
            return password.length() >= 8 &&
                   password.matches(".*[A-Z].*") &&
                   password.matches(".*\\d.*") &&
                   password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        }

        public boolean checkCellPhoneNumber(String number) {
            return number.matches("^\\+27\\d{9}$"); 
        }

        public String registerUser(String username, String password, String cellNumber, String firstName, String lastName) {
            if (!checkUserName(username)) {
                return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
            }

            if (!checkPasswordComplexity(password)) {
                return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
            }

            if (!checkCellPhoneNumber(cellNumber)) {
                return "Cell phone number incorrectly formatted or does not contain international code.";
            }

            registeredUser = new User(username, password, cellNumber, firstName, lastName);
            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
        }

        public boolean loginUser(String inputUsername, String inputPassword) {
            if (registeredUser == null) return false;

            return registeredUser.getUsername().equals(inputUsername) &&
                   registeredUser.getPassword().equals(inputPassword);
        }

        public String returnLoginStatus(String inputUsername, String inputPassword) {
            if (loginUser(inputUsername, inputPassword)) {
                return "Welcome " + registeredUser.getFirstName() + " " + registeredUser.getLastName() + ", it is great to see you again.";
            } else {
                return "Username or password incorrect, please try again.";
            }
        }
    }

    public static void main(String[] args) {
        Login loginSystem = new Login();

        

        // Registration
        String username = JOptionPane.showInputDialog("Register\nEnter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String cellNumber = JOptionPane.showInputDialog("Enter cell phone number (+27xxxxxxxxx):");
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        String registrationMessage = loginSystem.registerUser(username, password, cellNumber, firstName, lastName);
        JOptionPane.showMessageDialog(null, registrationMessage);

        // Login with up to 3 attempts
        if (registrationMessage.contains("successfully")) {
            int attempts = 3;
            while (attempts > 0) {
                String loginUsername = JOptionPane.showInputDialog("Login\nEnter username:");
                String loginPassword = JOptionPane.showInputDialog("Enter password:");

                if (loginSystem.loginUser(loginUsername, loginPassword)) {
                    JOptionPane.showMessageDialog(null, loginSystem.returnLoginStatus(loginUsername, loginPassword));
                    break;
                } else {
                    attempts--;
                    if (attempts == 0) {
                        JOptionPane.showMessageDialog(null, "Too many failed attempts. Access denied.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Incorrect login. Attempts remaining: " + attempts);
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please restart the registration with correct inputs.");
        }
    }
}
